# Newspeak Web IDE (as PWA)

This version of the Newspeak Web IDE uses PWA capabilities like ServiceWorker (`sw.js`) and Caching (`newspeak-ide-cache`). All of the `assets` from the `public` folder are cached.



